from django.contrib import admin
from django.urls import path
from . import views as userViews

urlpatterns = [
    path('register/', userViews.UserRegistrationView.as_view()),
    path('login/', userViews.UserLoginView.as_view()),
    path('profile/', userViews.UserProfileView.as_view()),
    # path('login/', userViews.loginUser),
]